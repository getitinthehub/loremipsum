/**
 * Started on 13-4-2017
 *
 * @author Thomas Holleman
 */
public class ElementallyException extends Exception {
    public ElementallyException(String message) {
        super(message);
    }
}
